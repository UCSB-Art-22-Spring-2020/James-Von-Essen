var x = 0; //starting horizontal piont for shape
var y = 0; //starting vertical piont for shape

var xSpeed = 5; //number of horizontal pixels x moves each frame 
var ySpeed = 5; //number of vertical pixels y moves each frame 

function setup() {
  createCanvas(1597,987); //window size using fibonnacci numbers
  background(255,255,255); //continuous white background
}

function draw() {
  stroke(random(255),random(255),random(255),200); //outline color of shape, assigned to change at random with opacitiy of 200/255
 strokeWeight(2); //thickness of outline set to 2 pixels
 fill(random(255),random(255),random(255),128); //fill color of shape, assigned to change at random with opacitiy of 200/255

 x = x + xSpeed; //sets movement of coordinate x, starts at 0 and moves horizontally in increments set by parameter xSpeed
 
 if(x > width || x < 0){ //sets limit to x coordinate within size/width = 1597
 xSpeed *= -1; //reverses velocity of movement x dependant on position within horizontal parameters
}

y = y + ySpeed; //sets movement of coordinate y, starts at 0 and moves vertically in increments set by parameter ySpeed

if(y > height || y < 0){ //sets limit to x coordinate within size/height = 987
 ySpeed = ySpeed*-1; //reverses velocity of movement y dependant on position within vertical parameters
}

ellipse(x,y,50,50);
}