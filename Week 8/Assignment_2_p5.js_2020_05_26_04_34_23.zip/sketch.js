//James Von Essen
//Assignment 2
//10 April, 2020
var x,y;
var h,s,b;
var i;

function setup(){
 createCanvas(1920,1080);
 
 x = width/2; //starting point for X in the middle of width
 y = height/2; // starting point for y in the middle of height

 colorMode(HSB); //Hue, Saturation, Brightness
}




function draw(){
  background(x/10.66,360,y/3); // changing background color based on HSB, Hue controlled by x position, full saturation, brightness controlled by y position
  fill(255);{ //key controlled moving ellipse filled with white so it's easy to follow 
  ellipse(x,y,10,10); //circle at x,y position sized 25x25 pixels
  }
  
  for(let i = 0; i < y/20+1; i++){  //start count at 0, keep counting while i is less than the position(0<y<1080)/20+1. as the coordinate of "y" get closer to the bottom of the window more ellipses are created
    stroke(0); //black stroke on randomly assigned ellipses
    fill(random(x/5,x/10),y/3,360); // fill color of ellipses dependent on x and y coordinates  
    ellipse(random(0,width),random(0,height),random(60,100),random(60,100)); //random position filling screen and random size from 60px-100px for width & height
  }
    
     if (x > width) { //If x is greater than the width of the window 
      x = 0; //then it resets to zero
   }
   if (x < 0) { //If x is less than 0
      x = width; //then it resets to the width of the window
   }
   if (y > height) { //If y is greater than the height of the window
      y = 0; //then it resets to zero
   }
   if (y < 0) { //If y is less than 0
      y = height; //then it resets to the height of the window
   }    
}
function keyPressed() {
  if (keyCode === RIGHT_ARROW) {
    x+=5;
  }
  if (keyCode === LEFT_ARROW) {//keyPressed) { //if a key is pressed
    x-=5;
  }
  if (keyCode === DOWN_ARROW) {
    y+=5;
  }
  if (keyCode === UP_ARROW) {
    y-=5;
  }
}